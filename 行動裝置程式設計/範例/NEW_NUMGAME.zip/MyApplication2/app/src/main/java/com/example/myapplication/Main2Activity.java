package com.example.myapplication;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.activity_game_result;

public class Main2Activity extends AppCompatActivity {
    private TextView mTxtResult,mTxV_S;
    private int checknum;
    private ImageButton mImgBtnnum01, mImgBtnnum02, mImgBtnnum03, mImgBtnnum04, mImgBtnnum05, mImgBtnnum06;
    private ImageView mImgViewCom,mImgViewPLAY;



    // 新增統計遊戲局數和輸贏的變數
    private int miCountSet = 0,
            miCountPlayerWin = 0,
            miCountComWin = 0,
            miCountDraw = 0;

    private Button mBtnShowResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mTxV_S = findViewById(R.id.V_S);
        mImgViewPLAY = findViewById(R.id.imgViewPLAY);
        mImgViewCom = findViewById(R.id.imgViewCom);
        mTxtResult = findViewById(R.id.txtResult);
        mImgBtnnum01 = findViewById(R.id.imgBtn_num1);
        mImgBtnnum02 = findViewById(R.id.imgBtn_num2);
        mImgBtnnum03 = findViewById(R.id.imgBtn_num3);
        mImgBtnnum04 = findViewById(R.id.imgBtn_num4);
        mImgBtnnum05 = findViewById(R.id.imgBtn_num5);
        mImgBtnnum06 = findViewById(R.id.imgBtn_num6);


        mImgBtnnum01.setOnClickListener(imgBtnNUM01OnClick);
        mImgBtnnum02.setOnClickListener(imgBtnNUM02OnClick);
        mImgBtnnum03.setOnClickListener(imgBtnNUM03OnClick);
        mImgBtnnum04.setOnClickListener(imgBtnNUM04OnClick);
        mImgBtnnum05.setOnClickListener(imgBtnNUM05OnClick);
        mImgBtnnum06.setOnClickListener(imgBtnNUM06OnClick);


        mBtnShowResult = (Button) findViewById(R.id.btnShowResult);
        mBtnShowResult.setOnClickListener(btnShowResultOnClick);
    }


    private View.OnClickListener imgBtnNUM01OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            miCountSet++;
            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 1;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_1);
                mTxtResult.setText(getString(R.string.draw));
                miCountDraw++;
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_1);
                mTxtResult.setText(getString(R.string.lose));
                miCountComWin++;
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_1);
                mTxtResult.setText(getString(R.string.win));
                miCountPlayerWin++;
            }
            switch (iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);
                    ;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);
                    ;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);
                    ;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);
                    ;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);
                    ;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);
                    ;
                    break;
                default:
            }
        }
    };

    private View.OnClickListener imgBtnNUM02OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            miCountSet++;
            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 2;
            mTxV_S.setText(getString(R.string.V_S));
            ;
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_2);
                mTxtResult.setText(getString(R.string.draw));
                miCountDraw++;
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_2);
                mTxtResult.setText(getString(R.string.lose));
                miCountComWin++;
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_2);
                mTxtResult.setText(getString(R.string.win));
                miCountPlayerWin++;
            }
            switch (iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);
                    ;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);
                    ;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);
                    ;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);
                    ;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);
                    ;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);
                    ;
                    break;
                default:
            }
        }
    };

    private View.OnClickListener imgBtnNUM03OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            miCountSet++;
            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 3;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_3);
                mTxtResult.setText(getString(R.string.draw));
                miCountDraw++;
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_3);
                mTxtResult.setText(getString(R.string.lose));
                miCountComWin++;
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_3);
                mTxtResult.setText(getString(R.string.win));
                miCountPlayerWin++;
            }
            switch (iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);
                    ;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);
                    ;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);
                    ;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);
                    ;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);
                    ;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);
                    ;
                    break;
                default:
            }
        }
    };
    private View.OnClickListener imgBtnNUM04OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            miCountSet++;
            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 4;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_4);
                mTxtResult.setText(getString(R.string.draw));
                miCountDraw++;
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_4);
                mTxtResult.setText(getString(R.string.lose));
                miCountComWin++;
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_4);
                mTxtResult.setText(getString(R.string.win));
                miCountPlayerWin++;
            }
            switch (iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);
                    ;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);
                    ;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);
                    ;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);
                    ;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);
                    ;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);
                    ;
                    break;
                default:
            }
        }
    };

    private View.OnClickListener imgBtnNUM05OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            miCountSet++;
            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 5;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_5);
                mTxtResult.setText(getString(R.string.draw));
                miCountDraw++;
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_5);
                mTxtResult.setText(getString(R.string.lose));
                miCountComWin++;
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_5);
                mTxtResult.setText(getString(R.string.win));
                miCountPlayerWin++;
            }
            switch (iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);
                    ;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);
                    ;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);
                    ;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);
                    ;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);
                    ;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);
                    ;
                    break;
                default:
            }
        }
    };
    private View.OnClickListener imgBtnNUM06OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            miCountSet++;
            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 6;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_6);
                mTxtResult.setText(getString(R.string.draw));
                miCountDraw++;
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_6);
                mTxtResult.setText(getString(R.string.lose));
                miCountComWin++;
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_6);
                mTxtResult.setText(getString(R.string.win));
                miCountPlayerWin++;
            }
            switch (iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);
                    ;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);
                    ;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);
                    ;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);
                    ;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);
                    ;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);
                    ;
                    break;
                default:
            }
        }
    };


    private View.OnClickListener btnShowResultOnClick = new View.OnClickListener() {
        public void onClick(View v) {
            Intent it = new Intent();
            it.setClass(Main2Activity.this, activity_game_result.class);

            Bundle bundle = new Bundle();
            bundle.putInt("KEY_COUNT_SET", miCountSet);
            bundle.putInt("KEY_COUNT_PLAYER_WIN", miCountPlayerWin);
            bundle.putInt("KEY_COUNT_COM_WIN", miCountComWin);
            bundle.putInt("KEY_COUNT_DRAW", miCountDraw);
            it.putExtras(bundle);

            startActivity(it);
        }

    };
}

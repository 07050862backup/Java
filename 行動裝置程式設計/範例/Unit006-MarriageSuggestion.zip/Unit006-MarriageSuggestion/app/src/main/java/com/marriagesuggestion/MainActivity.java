package com.marriagesuggestion;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    private Button mBtnOK;
    private TextView mTxtR, mtxchangegrade;
    private Spinner mSpn;
    private RadioGroup mradGrpScore;
    private RadioButton mradBtn0, mradBtn15, mradBtn25;
    private String gck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mtxchangegrade = (TextView) findViewById(R.id.change_grade);//自己加的，覆誦一次年級
        mBtnOK = (Button) findViewById(R.id.btnOK);
        mBtnOK.setOnClickListener(btnOKOnClick);
        mTxtR = (TextView) findViewById(R.id.txtR);
        mSpn = (Spinner) findViewById(R.id.spngrade);
        mSpn.setOnItemSelectedListener(spnGradeOnItemSelected);
        mradGrpScore = (RadioGroup) findViewById(R.id.radGrpScore);
        mradBtn0 = (RadioButton) findViewById(R.id.radBtn0);
        mradBtn15 = (RadioButton) findViewById(R.id.radBtn15);
        mradBtn25 = (RadioButton) findViewById(R.id.radBtn25);
    }
    private View.OnClickListener btnOKOnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String strgrade = gck;
            RadioGroup radGrpScore = (RadioGroup) findViewById(R.id.radGrpScore);
            if (strgrade.equals(getString(R.string.grade_check))) {
                String strSug = getString(R.string.first_grade);
                RadioGroup radGrpSex = (RadioGroup) findViewById(R.id.radGrpScore);
                switch (radGrpSex.getCheckedRadioButtonId()) {
                    case R.id.radBtn0:
                        strSug += getString(R.string.little);
                        mTxtR.setText(strSug);
                        break;
                    case R.id.radBtn15:
                        strSug += getString(R.string.medium);
                        mTxtR.setText(strSug);
                        break;
                    case R.id.radBtn25:
                        strSug += getString(R.string.many);
                        mTxtR.setText(strSug);
                        break;
                }
            } else {
                String strSugo = getString(R.string.notfirst);
                RadioGroup radGrpSex = (RadioGroup) findViewById(R.id.radGrpScore);
                switch (radGrpSex.getCheckedRadioButtonId()) {
                    case R.id.radBtn0:
                        strSugo += getString(R.string.little);
                        mTxtR.setText(strSugo);
                        break;
                    case R.id.radBtn15:
                        strSugo += getString(R.string.medium);
                        mTxtR.setText(strSugo);
                        break;
                    case R.id.radBtn25:
                        strSugo += getString(R.string.many);
                        mTxtR.setText(strSugo);
                        break;
                }
            }
        }
    };
    public AdapterView.OnItemSelectedListener spnGradeOnItemSelected = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String showGrade = getString(R.string.your_grade_is);
            showGrade += adapterView.getSelectedItem().toString();
            gck = adapterView.getSelectedItem().toString();
            mtxchangegrade.setText(showGrade);
        }
        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
            mtxchangegrade.setText(R.string.not_choose);
        }
    };
}

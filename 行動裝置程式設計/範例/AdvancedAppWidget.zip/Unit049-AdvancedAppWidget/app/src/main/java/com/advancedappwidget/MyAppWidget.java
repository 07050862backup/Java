package com.advancedappwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

public class MyAppWidget extends AppWidgetProvider {
    private Handler mhandler;
    private static final String LOG_TAG = "MyAppWidget";

    private static AlarmManager mAlarmManager;
    private static PendingIntent mPendingIntent;

    static void SaveAlarmManager(AlarmManager alarmManager, PendingIntent pendingIntent)
    {
        mAlarmManager = alarmManager;
        mPendingIntent = pendingIntent;
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        Log.d(LOG_TAG, "onDeleted()");
        mAlarmManager.cancel(mPendingIntent);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        Log.d(LOG_TAG, "onDisabled()");
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        Log.d(LOG_TAG, "onEnabled()");
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if(!intent.getAction().equals("com.android.MY_OWN_WIDGET_UPDATE"))
            return;

        Log.d(LOG_TAG, "onReceive()");

        AppWidgetManager appWidgetMan = AppWidgetManager.getInstance(context);
        ComponentName thisAppWidget = new ComponentName(context.getPackageName(),
                MyAppWidget.class.getName());
        int[] appWidgetIds = appWidgetMan.getAppWidgetIds(thisAppWidget);

        onUpdate(context, appWidgetMan, appWidgetIds);
    }

    @Override
    public void onUpdate(final Context context, AppWidgetManager appWidgetManager,
                         int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);

        mhandler=new Handler(Looper.getMainLooper());
        mhandler.post(new Runnable(){
            public void run(){
                Toast.makeText(context.getApplicationContext(), "Toast訊息!", Toast.LENGTH_LONG).show();
            }
        });
        Log.d(LOG_TAG, "onUpdate()");

    }
}

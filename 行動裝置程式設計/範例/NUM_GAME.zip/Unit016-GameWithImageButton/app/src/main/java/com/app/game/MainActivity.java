package com.app.game;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mTxtResult,mTxV_S;
    private int checknum;
    private ImageButton mImgBtnnum01, mImgBtnnum02, mImgBtnnum03, mImgBtnnum04, mImgBtnnum05, mImgBtnnum06;
    private ImageView mImgViewCom,mImgViewPLAY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTxV_S       = findViewById(R.id.V_S);
        mImgViewPLAY = findViewById(R.id.imgViewPLAY);
        mImgViewCom = findViewById(R.id.imgViewCom);
        mTxtResult = findViewById(R.id.txtResult);
        mImgBtnnum01 = findViewById(R.id.imgBtn_num1);
        mImgBtnnum02 = findViewById(R.id.imgBtn_num2);
        mImgBtnnum03 = findViewById(R.id.imgBtn_num3);
        mImgBtnnum04 = findViewById(R.id.imgBtn_num4);
        mImgBtnnum05 = findViewById(R.id.imgBtn_num5);
        mImgBtnnum06 = findViewById(R.id.imgBtn_num6);


        mImgBtnnum01.setOnClickListener(imgBtnNUM01OnClick);
        mImgBtnnum02.setOnClickListener(imgBtnNUM02OnClick);
        mImgBtnnum03.setOnClickListener(imgBtnNUM03OnClick);
        mImgBtnnum04.setOnClickListener(imgBtnNUM04OnClick);
        mImgBtnnum05.setOnClickListener(imgBtnNUM05OnClick);
        mImgBtnnum06.setOnClickListener(imgBtnNUM06OnClick);
    }

    private View.OnClickListener imgBtnNUM01OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 1;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_1);
                mTxtResult.setText(getString(R.string.draw));
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_1);
                mTxtResult.setText(getString(R.string.lose));
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_1);
                mTxtResult.setText(getString(R.string.win));
            }
            switch(iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);;
                    break;
                default:
            }
        }
    };

    private View.OnClickListener imgBtnNUM02OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 2;
            mTxV_S.setText(getString(R.string.V_S));;
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_2);
                mTxtResult.setText(getString(R.string.draw));
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_2);
                mTxtResult.setText(getString(R.string.lose));
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_2);
                mTxtResult.setText(getString(R.string.win));
            }
            switch(iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);;
                    break;
                default:
            }
        }
    };

    private View.OnClickListener imgBtnNUM03OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 3;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_3);
                mTxtResult.setText(getString(R.string.draw));
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_3);
                mTxtResult.setText(getString(R.string.lose));
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_3);
                mTxtResult.setText(getString(R.string.win));
            }
            switch(iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);;
                    break;
                default:
            }
        }
    };
    private View.OnClickListener imgBtnNUM04OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 4;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_4);
                mTxtResult.setText(getString(R.string.draw));
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_4);
                mTxtResult.setText(getString(R.string.lose));
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_4);
                mTxtResult.setText(getString(R.string.win));
            }
            switch(iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);;
                    break;
                default:
            }
        }
    };

    private View.OnClickListener imgBtnNUM05OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 5;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_5);
                mTxtResult.setText(getString(R.string.draw));
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_5);
                mTxtResult.setText(getString(R.string.lose));
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_5);
                mTxtResult.setText(getString(R.string.win));
            }
            switch(iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);;
                    break;
                default:
            }
        }
    };
    private View.OnClickListener imgBtnNUM06OnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            int iComPlay = (int) (Math.random() * 6 + 1);
            checknum = 6;
            mTxV_S.setText(getString(R.string.V_S));
            if (iComPlay == checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_6);
                mTxtResult.setText(getString(R.string.draw));
            } else if (iComPlay > checknum) {
                mImgViewPLAY.setImageResource(R.drawable.num_6);
                mTxtResult.setText(getString(R.string.lose));
            } else {
                mImgViewPLAY.setImageResource(R.drawable.num_6);
                mTxtResult.setText(getString(R.string.win));
            }
            switch(iComPlay) {
                case 1:
                    mImgViewCom.setImageResource(R.drawable.num_1);;
                    break;
                case 2:
                    mImgViewCom.setImageResource(R.drawable.num_2);;
                    break;
                case 3:
                    mImgViewCom.setImageResource(R.drawable.num_3);;
                    break;
                case 4:
                    mImgViewCom.setImageResource(R.drawable.num_4);;
                    break;
                case 5:
                    mImgViewCom.setImageResource(R.drawable.num_5);;
                    break;
                case 6:
                    mImgViewCom.setImageResource(R.drawable.num_6);;
                    break;
                default:
            }
        }
    };

}
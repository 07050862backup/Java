package com.javascriptandapp;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class JavaScriptCallFunc extends MainActivity{

    Context mContext;

    JavaScriptCallFunc(Context c) {
        mContext = c;
    }

    @JavascriptInterface
    public void showdialogMsg(String s) {

/*   Toast.makeText(mContext, s, Toast.LENGTH_LONG)
                .show();*/


        AlertDialog.Builder altDlgBldr = new AlertDialog.Builder(mContext);
        altDlgBldr.setTitle("AlertDialog");
        altDlgBldr.setMessage("!!!!由網頁呼叫所建立的對話盒!!!!");
        altDlgBldr.setIcon(android.R.drawable.ic_dialog_info);
        altDlgBldr.setCancelable(false);
        altDlgBldr.setPositiveButton("是",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        altDlgBldr.setNegativeButton("否",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        altDlgBldr.setNeutralButton("取消",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        altDlgBldr.show();



    }

}

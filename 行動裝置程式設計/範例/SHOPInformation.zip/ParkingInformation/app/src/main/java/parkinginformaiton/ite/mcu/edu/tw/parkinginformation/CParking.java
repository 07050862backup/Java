package parkinginformaiton.ite.mcu.edu.tw.parkinginformation;

/**
 * Created by MCUMCU on 2017/12/27.
 */

public class CParking {
    private String Tel;
    private String Toldescribe;
    private String Name;
    private String Add;
    private String Zipcode;
    private String Opentime;
    private String Px;
    private String Py;
    private String Website;
    private String Parkinginfo;

    public CParking(String Tel, String Toldescribe, String Name, String Add, String Zipcode, String Opentime, String Px, String Py, String Website, String Parkinginfo) {
        this.Tel = Tel;
        this.Toldescribe = Toldescribe;
        this.Name = Name;
        this.Add = Add;
        this.Zipcode = Zipcode;
        this.Opentime = Opentime;
        this.Px = Px;
        this.Py = Py;
        this.Website = Website;
        this.Parkinginfo = Parkinginfo;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String Tel) {
        Tel = Tel;
    }

    public String getToldescribe() {
        return Toldescribe;
    }

    public void setToldescribe(String Toldescribe) {
        Toldescribe = Toldescribe;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        Name = Name;
    }

    public String getAdd() {
        return Add;
    }

    public void setAdd(String Add) {
        Add = Add;
    }

    public String getZipcode() {
        return Zipcode;
    }

    public void setZipcode(String Zipcode) {
        Zipcode = Zipcode;
    }

    public String getOpentime() {
        return Opentime;
    }

    public void setOpentime(String Opentime) {
        this.Opentime = Opentime;
    }

    public String getPx() {
        return Px;
    }

    public void setPx(String Px) {
        Px = Px;
    }

    public String getPy() {
        return Py;
    }

    public void setPy(String Py) {
        Py = Py;
    }

    public String getWebsite() {
        return Website;
    }

    public void setWebsite(String Website) {
        Website = Website;
    }

    public String getParkinginfo() {
        return Parkinginfo;
    }

    public void setParkinginfo(String Parkinginfo) {
        Parkinginfo = Parkinginfo;
    }

}

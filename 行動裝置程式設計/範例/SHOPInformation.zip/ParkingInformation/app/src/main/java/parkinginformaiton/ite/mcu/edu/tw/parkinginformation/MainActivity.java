package parkinginformaiton.ite.mcu.edu.tw.parkinginformation;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private int position=0;
    ArrayList<CParking> list;

    EditText txtTel;
    EditText txtToldescribe;
    EditText txtName;
    EditText txtAdd;
    EditText txtZipcode;
    EditText txtOpentime;
    EditText txtPx;
    EditText txtPy;
    EditText txtWebsite;
    EditText txtParkinginfo;

    TextView txtDatas;

    Button btnFirst;
    Button btnPrevious;
    Button btnNext;
    Button btnLast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy l_policy =  new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy( l_policy);

        initialComponent();
        loadData();
    }

    private void initialComponent() {
        txtTel=(EditText)findViewById(R.id.txtTel);
        txtToldescribe=(EditText)findViewById(R.id.txtToldescribe);
        txtName=(EditText)findViewById(R.id.txtName);
        txtAdd=(EditText)findViewById(R.id.txtAdd);
        txtZipcode=(EditText)findViewById(R.id.txtZipcode);
        txtOpentime=(EditText)findViewById(R.id.txtOpentime);
        txtPx=(EditText)findViewById(R.id.txtPx);
        txtPy=(EditText)findViewById(R.id.txtPy);
        txtWebsite=(EditText)findViewById(R.id.txtWebsite);
        txtParkinginfo=(EditText)findViewById(R.id.txtParkinginfo);

        txtDatas=(TextView)findViewById(R.id.txtDatas);

        btnFirst=(Button)findViewById(R.id.btnFirst);
        btnFirst.setOnClickListener(btnFirst_click);
        btnPrevious=(Button)findViewById(R.id.btnPrevious);
        btnPrevious.setOnClickListener(btnPrevious_click);
        btnNext =(Button)findViewById(R.id.btnNext);
        btnNext.setOnClickListener(btnNext_click);
        btnLast=(Button)findViewById(R.id.btnLast);
        btnLast.setOnClickListener(btnLast_click);


    }

    private void loadData(){
        list=new ArrayList<CParking>();

        try {
            URL url=new URL("https://data.tycg.gov.tw/opendata/datalist/datasetMeta/download?id=8dc035f1-0770-4522-8c98-96d98bb0530e&rid=9f126a52-5bea-41ff-a769-96b0f1df0f51");
            URLConnection conn=url.openConnection();
            InputStream streamIn=conn.getInputStream();

            BufferedReader r = new BufferedReader(new InputStreamReader(streamIn));
            StringBuilder html = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                html.append(line);
            }
            txtTel.setText(String.valueOf(html.length()));
            try {
                String tmp=html.toString();
                JSONArray ja=new JSONObject(tmp).getJSONArray("infos");
                for(int i=0;i<ja.length();i++){
                    JSONObject o = ja.getJSONObject(i);
                    list.add(new CParking(o.getString("Tel"),
                            o.getString("Toldescribe"),
                            o.getString("Name"),
                            o.getString("Add"),
                            o.getString("Zipcode"),
                            o.getString("Opentime"),
                            o.getString("Px"),
                            o.getString("Py"),
                            o.getString("Website"),
                            o.getString("Parkinginfo")
                    ));
                }
                displayData();
            } catch (JSONException e) {
                e.printStackTrace();

            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    private View.OnClickListener btnFirst_click=new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            position=0;
            displayData();
        }
    };

    private void displayData() {
        txtDatas.setText("第"+String.valueOf(position+1)+"筆,總共"+String.valueOf(list.size())+"筆");
        txtTel.setText(list.get(position).getTel());
        txtToldescribe.setText(list.get(position).getToldescribe());
        txtName.setText(list.get(position).getName());
        txtAdd.setText(list.get(position).getAdd());
        txtZipcode.setText(list.get(position).getZipcode());
        txtOpentime.setText(list.get(position).getOpentime());
        txtPx.setText(list.get(position).getPx());
        txtPy.setText(list.get(position).getPy());
        txtWebsite.setText(list.get(position).getWebsite());
        txtParkinginfo.setText(list.get(position).getParkinginfo());
    }

    private View.OnClickListener btnPrevious_click=new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            position--;
            if(position<0)
                position=0;
            displayData();
        }
    };
    private View.OnClickListener btnNext_click=new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            position++;
            if(position>=list.size())
                position=list.size()-1;
            displayData();

        }
    };
    private View.OnClickListener btnLast_click=new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            position=list.size()-1;
            displayData();
        }
    };

}
